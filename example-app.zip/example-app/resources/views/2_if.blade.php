<html>
<body>
<font size='5' face='Arial'>
@unless($name=="laravel")
the subject is not laravel.
@endunless
</font>
</body>
</html>
