<html>
<body>
<font size='5' face='Arial'>
<?php if (! ($name=="laravel")): ?>
the subject is not laravel.
<?php endif; ?>
</font>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\example-app\resources\views/2_if.blade.php ENDPATH**/ ?>